<?php $this->load->view('header.php')?>
 <div class="inner-banner inner">
            <img src="<?php echo base_url();?>assets/asset/images/about-banner.png" alt="about banner" />
        </div>
        <!-- /.inner-banner -->
        <!-- ============== About ============== -->
        <div class=" about-page ">
            <div class="container">
                <div class="row">
											<div class="col-lg-3 col-md-3 col-sm-3 wow fadeInLeft" data-wow-duration="1s" data-wow-delay="0.5s">
							<h2>Telecom</h2>
						</div>
						<!-- /.col-lg-3 col-md-3 col-sm-3 -->
						<div class="wow bounceInUp col-lg-9 col-md-9 col-sm-9 " data-wow-duration="1s " data-wow-delay="0.5s "><h4>About Telecom Sector
</h4>
							<p><p>Telecom Services have been acknowledged globally as main tool for socio-economic development of Nation. India Falls on world's second largest telecommunications market & have gained tremendous growth in past years.
<br /><br /></p></p>
						</div>
									
                    <!-- /.col-lg-9 col-md-9 col-sm-9 -->
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container -->
        </div>
        <!-- /.about-page -->
        <!-- ============== Why choose us section ============== -->
       <div class="container journey_box">
        <div class="row">
    
        <div class="col-lg-12 col-md-12 col-sm-12">
		       
		        <p>
		        <p>
		       -	Telecom sector in India Presents unique opportunities & challenges. There is vast demand for skilled workforce in Telecom sector but training facility is not up to the mark to ensure continuous skill development of Trainees/Trainers. The rapid strides in the telecom sector have been Expediting by liberal policies of Govt. of India. That provides easy market access for telecom equipment & a fair regulatory framework for providing telecom services at affordable prices
<br /><br />
CPIT has conducted various programs to impart training under this sector. The trainees are given efficient knowledge to improve their telecommunication skills. The MES course related to this sector is TELECOM DTH Installation Technician.
<br /><br />
For Impacting various lives & crating livelihood, CPIT ensures to impart efficient & Productive training to make candidate to perform better, ready to be employed or even self employed in this particular sector.

<br /><br />

CPIT assures to provide training  in various courses aligned to  NCVT & SSC :<br />
			</p></p>
		        </div>
		
        </div>
        </div>
        <!-- ============== Add ============== -->
        
        <!-- /.container -->
        <!-- ============== Our team ============== -->
        
            <!-- /.container -->
        </div>
<br>

<br>
        

<?php $this->load->view('footer.php')?>