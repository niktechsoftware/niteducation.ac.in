<?php $this->load->view('header.php')?>
 <div class="inner-banner inner">
            <img src="<?php echo base_url();?>assets/asset/images/about-banner.png" alt="about banner" />
        </div>
        <!-- /.inner-banner -->
        <!-- ============== About ============== -->
        <div class=" about-page ">
            <div class="container">
                <div class="row">
											<div class="col-lg-3 col-md-3 col-sm-3 wow fadeInLeft" data-wow-duration="1s" data-wow-delay="0.5s">
							<h2> purpose of yoga</h2>
						</div>
						<!-- /.col-lg-3 col-md-3 col-sm-3 -->
						<div class="wow bounceInUp col-lg-9 col-md-9 col-sm-9 " data-wow-duration="1s " data-wow-delay="0.5s ">
							<p><p>The Purpose of Yoga. ... The original context of yoga was spiritual development practices to train the body and mind to self observe and become aware of their own nature. The purposes of yoga were to cultivate discernment, awareness, self-regulation and higher consciousness in the individual..<br /><br /></p></p>
						</div>
									
                    <!-- /.col-lg-9 col-md-9 col-sm-9 -->
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container -->
        </div>
        <!-- /.about-page -->
        <!-- ============== Why choose us section ============== -->
       <div class="container journey_box">
        <div class="row">
    
        <div class="col-lg-12 col-md-12 col-sm-12">
		       <h2>use of yoga</h2>
		        <p>
		        <p>
		      Importance of Yoga. Yoga is not a religion; it is a way of living that aims towards 'a healthy mind in a healthy body'. Man is a physical, mental and spiritual being; yoga helps promote a balanced development of all the three. Other forms of physical exercises, like aerobics, assure only physical well-being.
			</p></p><br>

<br>
		        </div>
		
        </div>
        </div>
        <!-- ============== Add ============== -->
        
        <!-- /.container -->
        <!-- ============== Our team ============== -->
        
            <!-- /.container -->
        </div>
<br>

<br>
        

<?php $this->load->view('footer.php')?>