<?php $this->load->view('header.php')?>
 <div class="inner-banner inner">
            <img src="<?php echo base_url();?>assets/asset/images/about-banner.png" alt="about banner" />
        </div>
        <!-- /.inner-banner -->
        <!-- ============== About ============== -->
        <div class=" about-page ">
            <div class="container">
                <div class="row">
											<div class="col-lg-3 col-md-3 col-sm-3 wow fadeInLeft" data-wow-duration="1s" data-wow-delay="0.5s">
							<h2>Beauty</h2>
						</div>
						<!-- /.col-lg-3 col-md-3 col-sm-3 -->
						<div class="wow bounceInUp col-lg-9 col-md-9 col-sm-9 " data-wow-duration="1s " data-wow-delay="0.5s ">
							<p><p>Beauty is the aspect of being appealing & attractive, especially to look at someone or something that gives great pleasure, especially when looking at it. Researchers have found that Good Looking Students get higher grades from their researchers than students with ordinary outlook. As the Country's economy is growing & the spending power of people is increasing, Beauty & Wellness sector has gained lot of advantage.<br />
	Interestingly, the Industry remains unaltered during inflation, Recession & Economic crisis in the world. Beauty & Wellness sector has gained prominence in India, but there is huge deficit in the availability of skilled & Trained Professional. This talent deficit poses extreme threat to the growth & expansion of the whole beauty & Wellness Industry. Developing skilled & Trained personnel is thus a Intimidating/ Encouraging task at hand for businesses as well as govt.<br /><br /></p></p>
						</div>
									
                    <!-- /.col-lg-9 col-md-9 col-sm-9 -->
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container -->
        </div>
        <!-- /.about-page -->
        <!-- ============== Why choose us section ============== -->
       <div class="container journey_box">
        <div class="row">
    
        <div class="col-lg-12 col-md-12 col-sm-12">
		       
		        <p>
		        <p>
		      NIT Institute of Technologies Is therefore implementing various programmes in the said sector. It provides theory as well as practical sessions to develop skills of beautician through various courses like Facial, Make-up, Hair coloring, Manicure/Pedicure & therefore developing various employments prospects . CPIT has full furnished labs , Infra as well as equipments.<br />


The Retail sector has played a remarkable role throughout the world in  increasing productivity  of Consumers' goods & services. The Indian Retail Industry is the largest industry among all Industries. The Retail Industry in India has come forth as one of the most effectual Industry with several players coming in the market, but all of them  haven't tasted success yet  as heavy investments  are required  to compete with various companies.<br /><br />

Programmes Implemented & Aligned with MES & SSC are:<br />
1.Assistant Beautician <br />
2.Assistant Hair Style <br />
3.Manicurist Pedicurist <br />
4.Beauty Therapy & Hair Styling <br />
5.Beauty Therapy & Hair Styling <br />
			</p></p>
		        </div>
		
        </div>
        </div>
        <!-- ============== Add ============== -->
        
        <!-- /.container -->
        <!-- ============== Our team ============== -->
        
            <!-- /.container -->
        </div>
<br>

<br>
        

<?php $this->load->view('footer.php')?>