<?php $this->load->view('header.php')?>
 <div class="inner-banner inner">
            <img src="<?php echo base_url();?>assets/asset/images/about-banner.jpg" alt="about banner" />
        </div>
        <!-- /.inner-banner -->
        <!-- ============== About ============== -->
        <div class=" about-page ">
            <div class="container">
                <div class="row">
											<div class="col-lg-3 col-md-3 col-sm-3 wow fadeInLeft" data-wow-duration="1s" data-wow-delay="0.5s">
							<h2>About US</h2>
						</div>
						<!-- /.col-lg-3 col-md-3 col-sm-3 -->
						<div class="wow bounceInUp col-lg-9 col-md-9 col-sm-9 " data-wow-duration="1s " data-wow-delay="0.5s ">
							<p>National Institute of Technologies Aamghat Ghazipur is a prestigious educational institute, which is working in Ghazipur more than 5 Years of excellence. Institute provides Technical Education as well as various others courses in the welfare of students in this competitive world. This Institute is run and managed by Ministry Of Micro, Small & Medium Enterprises, Govt. of India.. Institute has always been efforts forever in the excellence of proper guidance of education. National Institute Of Technologies Aamghat Ghazipur offers opportunities to choose a course that best meets a student's unique academic and professional needes.</p>
						</div>
									
                    <!-- /.col-lg-9 col-md-9 col-sm-9 -->
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container -->
        </div>
       
        </div>
<br>

<br>
        

<?php $this->load->view('footer.php')?>