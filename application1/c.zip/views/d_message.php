<?php $this->load->view('header.php')?>

       <br> <br> <br> <br> <br> <br> <br> <br> <br>
		
        <hr>
        
        </div>
        <div class="container">
		    <div class="row   wow fadeInLeft" data-wow-duration="0.5s" data-wow-delay="0.2s">
                <h3><strong>Direcor Message</strong></h3>
            </div>
		<div class="row">
                <div class="col-xs-4 col-lg-2 col-md-2 wow fadeInLeft" data-wow-duration="1s" data-wow-delay="0.5s">
                    <img src="<?php echo base_url();?>assets/asset/images/team1.jpg" class="img-responsive service" alt="sound" />
                </div>
                <div class="col-xs-8 col-lg-10 col-md-10  wow fadeInRight" data-wow-duration="1s" data-wow-delay="0.5s">
                    <h3 class="newws3">Surya Prakash Rai (Director)</h3>
                    <p class="news7">
                    It is my pleasure and privilege to take you around our Institute - National institute of Technologies, at Ghazipur (U.P.). The Institute is located in the heart of Ghazipur. The Institute has spacious building of 5000 sq. ft. with outstanding infrastructure amidst excellent surroundings.
                    </p>
                    <p>We at NITs have a track record of imparting quality education with an emphasis to prepare our management students as per requirements of industry for the challenges of tomorrow. We offer challenging curriculum which provides opportunities of academic achievements and at the same time also focuses on personal development of students. NITs strives to create a learning culture with emphasis on creative and analytical mind frame. We have excellent state of art facilities with most modern computer laboratories and brilliant faculties providing personal attention to each student. NITs  has excellent track record in the corporate world of producing quality professionals, adopt at handling challenges in the work place. Our placement record speaks for itself. Our library is equipped with all up-to-date books, journals for the students to up grade themselves on regular basis. We conduct regular Workshops, Seminars, Group Discussion etc.Our great nation is at the threshold of leading world with its IT and Management talent. We invite & welcome you empower yourself by joining the winning team of NITs's students and alumni, famous for its excellence.</p>
                </div>
                
         </div>
		<br>
        </div>
        <br>

<?php $this->load->view('footer.php')?>