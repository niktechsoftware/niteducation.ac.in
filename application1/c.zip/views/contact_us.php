<?php $this->load->view('header.php')?>
 <div class="inner-banner inner">
            <img src="<?php echo base_url();?>assets/asset/images/about-banner.png" alt="about banner" />
        </div>
	<div class="full-width main-home">
		<div class="container">
			
				<div class="col-md-8">
					<div class="main-home-content">
						<h1>Our Global Location</h1>
						  
						  	</div>
				</div>
				<div class="col-md-4">
					<div class="sidebar">
						<div class="sidebar-service">
							<h3> Contact Info </h3>
						</div>
						<div>
							<p style="color:green;"><span class="fa fa-home"> National Institute Of Technologies
 </span></p>
							<hr/>
							<p style="color:green;"><span class="fa fa-home"> Aamghat Colony,
                                      Ghazipur (UP) 233001</span></p>
							<hr/>
							<p style="color:green;"><span class="fa fa-phone"> +91-7275151420</span></p>
							<hr/>
							<p style="color:green;"><span class="fa fa-envelope-o"> info@niteducation.ac.in<br>contact@niteducation.ac.in</span></p>
							
							
							<br/>
						</div>			
					</div>
				</div>
			</div>
		</div>			
	</div>

<?php $this->load->view('footer.php')?>