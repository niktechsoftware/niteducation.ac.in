<?php
class registration extends CI_Controller{
	public function saveStudent(){
		$id = $this->db->query("SELECT id From student_info order by id DESC Limit 1")->row()->id;
		$id = 1000 + $id+1;
		$data = array(
				"student_id" => $id,
				"name" => $this->input->post("name"),
				"fName" => $this->input->post("fname"),
				"address" => $this->input->post("address"),
				"city" => $this->input->post("city"),
				"state" => $this->input->post("state"),
				"pin" => $this->input->post("pin"),
				"mobile" => $this->input->post("mobile"),
				"mother_name"=>$this->input->post("mother_name"),
				"aadhar_number"=>$this->input->post("aadhar_number"),
				"dob" => date("Y-m-d", strtotime($this->input->post("dob"))),
				"nationality"=>$this->input->post("nationality"),
				"community"=>$this->input->post("community"),
				"heighQ" => $this->input->post("heighQ"),
				"courseApplied" => $this->input->post("courseApplied"),
				"timing" => $this->input->post("timing"),
				"gender" => $this->input->post("gender"),
				"email" => $this->input->post("email"),
				"branch_id" => $this->input->post("branchId"),
				"branch_no" => $this->input->post("branchNo"),
				"remark"=>$this->input->post("remark"),
				"isApprove" => "NO",
				"pay_amount" =>$this->input->post("total_fee"),
				"status" =>"pending"
		);
		
		$this->db->insert("web_student_requ",$data);
		$data1 = array(
			"purpose" => $this->input->post("courseApplied"),
			"amount" => $this->input->post("total_fee"),
			"buyer_name" => $id,
			"phone" => $this->input->post("mobile"),
			"send_email" => true,
			"send_sms" => true,
			"email" => $this->input->post("email")
		);
		
		$this->session->set_userdata('payment',$data1);
		
		redirect(base_url()."registration/instapayment");
	}
	
	public function instamojo() {
		echo "success";
	}
	
	public function instaPayment() {
		$payment = $this->session->userdata('payment');

		$product_name = $payment['purpose'];
		$price = $payment['amount'];
		$name = $payment['buyer_name'];
		$phone = $payment['phone'];
		$email = $payment['email'];
		
		$data = array(
			"purpose" => $payment['purpose'],
			"amount" => $price,
			"phone" => $payment['phone'],
			"buyer_name" => $payment['buyer_name'],
			"redirect_url" => base_url()."registration/printRegister/$name",
			"send_email" => false,
			"webhook" => "http://niteducation.ac.in/instamojo/payment",
			"send_sms" => false,
			"email" => "kpushpendra81@gmail.com",
			"allow_repeated_payments" => false
		);
		
		
		$curl = curl_init();
		
		curl_setopt_array($curl, array(
		  CURLOPT_URL => "https://www.instamojo.com/api/1.1/payment-requests/",
		  CURLOPT_RETURNTRANSFER => true,
		  CURLOPT_ENCODING => "",
		  CURLOPT_MAXREDIRS => 10,
		  CURLOPT_TIMEOUT => 30,
		  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		  CURLOPT_CUSTOMREQUEST => "POST",
		  CURLOPT_POSTFIELDS => json_encode($data),
		  CURLOPT_HTTPHEADER => array(
		    "content-type: application/json",
		    "x-api-key: ed3fc46b07333211a21e165ac6a0c9a7",
		    "x-auth-token: 7d25c627d043f2e89b1916fbfe5baa27"
		  ),
		));
		
		$response = curl_exec($curl);
		$err = curl_error($curl);
		
		curl_close($curl);
		
		if ($err) {
		  echo "cURL Error #:" . $err;
		} else {
		  echo $response;
		  $resp = json_decode($response);
		  echo '<pre>';
		  print_r($resp);
		  echo '</pre>';
		  redirect($resp->payment_request->longurl);
		}
	}
	
	
		public function printRegister(){
			
			$data['stu_id'] = $this->uri->segment(3);
			$this->load->view("printRegister",$data);
		}
		
	
}