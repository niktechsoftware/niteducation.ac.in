<?php $this->load->view('header.php')?>
 <div class="inner-banner inner">
            <img src="<?php echo base_url();?>assets/asset/images/about-banner.png" alt="about banner" />
        </div>
        <!-- /.inner-banner -->
        <!-- ============== About ============== -->
        <div class=" about-page ">
            <div class="container">
                <div class="row">
											<div class="col-lg-3 col-md-3 col-sm-3 wow fadeInLeft" data-wow-duration="1s" data-wow-delay="0.5s">
							<h2>IT</h2>
						</div>
						<!-- /.col-lg-3 col-md-3 col-sm-3 -->
						<div class="wow bounceInUp col-lg-9 col-md-9 col-sm-9 " data-wow-duration="1s " data-wow-delay="0.5s "><h4>About Information Technology Sector</h4>
							<p><p>Information technology in India is an Industry comprising two major parts-
Ist part is Outsourcing of Business Process (BPO) & the other part is Information Technology related services. The sector has increased its contribution to India's GDP from 1.2% in 1998 to 7.5%. The Goal of IT-Ities SSC is to create a sustainable industry ready talent pipeline by scaling Quality capacity & to enhance employability at all levels, leveraging technology & our experience in large scale skill development, in a feasible manner across skill sectors.
<br /><br /></p></p>
						</div>
									
                    <!-- /.col-lg-9 col-md-9 col-sm-9 -->
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container -->
        </div>
        <!-- /.about-page -->
        <!-- ============== Why choose us section ============== -->
       <div class="container journey_box">
        <div class="row">
    
        <div class="col-lg-12 col-md-12 col-sm-12">
		       <h4>EFFICIENT LEARNING & SKILLS ACQUIRED FOR CANDIDATES TO WORK EFFECTIVELY.</h4>
		        <p>
		        <p>
		       -	Efficient English communication Skills.<br />
-	 Good Techniques for appearing in Interview.<br />
-	MS- World Documentation.<br />
-	Preparing Effective Presentation in MS- PowerPoint.<br />
-	Quick & Easy calculations & Data handling Via Excel.<br />
-	Surfing Internet, Chatting, Emailing & Information downloading.<br /><br /><br /><br />

CPIT assures to provide training  in various courses aligned to  NCVT & SSC :<br />
			</p></p>
		        </div>
		
        </div>
        </div>
        <!-- ============== Add ============== -->
        
        <!-- /.container -->
        <!-- ============== Our team ============== -->
        
            <!-- /.container -->
        </div>
<br>

<br>
        

<?php $this->load->view('footer.php')?>