<?php $this->load->view('header.php')?>
 <div class="inner-banner inner">
           
        </div>
        <!-- /.inner-banner -->
        <!-- ============== About ============== -->
        <div class=" about-page ">
            <div class="container">
                <div class="row">
											<div class="col-lg-3 col-md-3 col-sm-3 wow fadeInLeft" data-wow-duration="1s" data-wow-delay="0.5s">
							<h2>Pay Fee</h2>
						</div>
						<!-- /.col-lg-3 col-md-3 col-sm-3 -->
						<div class="wow bounceInUp col-lg-9 col-md-9 col-sm-9 " data-wow-duration="1s " data-wow-delay="0.5s ">
							<br>
								<br>
									<br>
										<br>
										<h3>Please Enter Your Roll Number (Registration Number) of Institute.</h3>
										<br>
										
                                   <div class="form-group">
                                            <label for="inputEmail3" class="col-sm-2 control-label">Roll Number</label>
                                            <div class="col-sm-4">
                                                <input class="form-control" type="text" name="rollnumber"  required="required">
                                            </div>
                                             <div class="col-sm-4">
                                                <input class="form-control" type="submit" >
                                            </div>
                                            </div>
                                            <br></br>
                                  </div>
						</div>
									
                    <!-- /.col-lg-9 col-md-9 col-sm-9 -->
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container -->
       
<br>

<br>
        

<?php $this->load->view('footer.php')?>