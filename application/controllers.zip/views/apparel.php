<?php $this->load->view('header.php')?>
 <div class="inner-banner inner">
            <img src="<?php echo base_url();?>assets/asset/images/about-banner.png" alt="about banner" />
        </div>
        <!-- /.inner-banner -->
        <!-- ============== About ============== -->
        <div class=" about-page ">
            <div class="container">
                <div class="row">
											<div class="col-lg-3 col-md-3 col-sm-3 wow fadeInLeft" data-wow-duration="1s" data-wow-delay="0.5s">
							<h2>APPAREL</h2>
						</div>
						<!-- /.col-lg-3 col-md-3 col-sm-3 -->
						<div class="wow bounceInUp col-lg-9 col-md-9 col-sm-9 " data-wow-duration="1s " data-wow-delay="0.5s ">
							<p><p>The Textile Industry or Apparel Industry is primarily related with the design & production of Yarn, Cloth, Clothing & their distribution. The raw material that is used may be natural or synthetic using products of the Chemical Industry.</p></p>
						</div>
									
                    <!-- /.col-lg-9 col-md-9 col-sm-9 -->
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container -->
        </div>
        <!-- /.about-page -->
        <!-- ============== Why choose us section ============== -->
       <div class="container journey_box">
        <div class="row">
    
        <div class="col-lg-12 col-md-12 col-sm-12">
		        <h3>Reasons to Invest:</h3>
		        <p>
		        <p>
		        	The Indian Accounting Industry  accounts for about 24 % of the world's  spindle capacity  & 8%  of global rotor capacity.<br />
	India comes on  second largest  manufacturing capacity Globally.<br />
	India accounts for about  14% of the  World's  production  of textile fiber & yarn  & is the largest producer of Jute  & the second largest  producer of  Skill & Cotton.<br />
	Increased  Insertion of organized retail , favorable demographics  & rising  Income Levels  to drive textile  demand.<br />
	Abundant Raw- Material & Increasing demand for exports  to  boost fiber Production.<br />
	Abundant availability of raw-material  such as cotton, wool, silk & Jute.<br />
	India enjoys a comparative advantage  in  terms of skilled manpower  & cost  of production  over major textile producers.<br /><br />
		        
		        </p>
		      <h3>Reasons to Invest:</h3>  
		      <p>

•	Fabrics  Processing set-ups  for  all kind of  natural & Synthetic textiles.<br />
•	Technical Textile.<br />
•	Garments<br />
•	Retail Brands<br />
•	Value  added & Specialty Fabrics.<br />
•	Complete  value chain of Synthetic.<br /><br /></p>
<p>
As there are  more & more  Technological  advancement  & Rapid Industrial Growth , Labor Intensive  Industries required skilled workforce as well as  efficient training  for  skill up gradation of  existing workers  & enabling them  to gain efficiency  in various sectors  such as handloom , Power loom,  sericulture, wool etc. to reduce  the gap  between Training  needs  of  separate segments & Training. CPIT assures  to bridge  the maximum gap  & Alignment  of training as per  requirement  of Industry  &  course curriculum  synchronized with NCVT.<br /><br />
Various  Programs  conducted  for NATIONAL  COUNCIL OF VOCATIONAL TRAINING(NCVT) & SSC certified course verification are:<br />
			</p></p>
		        </div>
		
        </div>
        </div>
        <!-- ============== Add ============== -->
        
        <!-- /.container -->
        <!-- ============== Our team ============== -->
        
            <!-- /.container -->
        </div>
<br>

<br>
        

<?php $this->load->view('footer.php')?>