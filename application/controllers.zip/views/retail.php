<?php $this->load->view('header.php')?>
 <div class="inner-banner inner">
            <img src="<?php echo base_url();?>assets/asset/images/about-banner.png" alt="about banner" />
        </div>
        <!-- /.inner-banner -->
        <!-- ============== About ============== -->
        <div class=" about-page ">
            <div class="container">
                <div class="row">
											<div class="col-lg-3 col-md-3 col-sm-3 wow fadeInLeft" data-wow-duration="1s" data-wow-delay="0.5s">
							<h2>APPAREL</h2>
						</div>
						<!-- /.col-lg-3 col-md-3 col-sm-3 -->
						<div class="wow bounceInUp col-lg-9 col-md-9 col-sm-9 " data-wow-duration="1s " data-wow-delay="0.5s ">
							<p><p>Retail is the process of selling consumer goods and/or services  to customers  through different channels  of dispensation to earn  a profit.  Demand is created through diverse target markets and promotional tactics, satisfying consumers' wants and needs through a framework of  supply chain.<br />
	The Indian retail industry is the largest among all the industries, Adjudging  for over 10% of the country's GDP & around 8 %  of the employment . The Retail Industry  in India has come forth  as one of the  most dynamic  & fast paced industries  with several players  entering the market, but all of them have not yet tasted success  because of the heavy initial investments  that are required to break  even with other  companies  & to compete with them. The Indian retail industry is moving slowly its way towards becoming the next blast industry.<br /><br /></p></p>
						</div>
									
                    <!-- /.col-lg-9 col-md-9 col-sm-9 -->
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container -->
        </div>
        <!-- /.about-page -->
        <!-- ============== Why choose us section ============== -->
       <div class="container journey_box">
        <div class="row">
    
        <div class="col-lg-12 col-md-12 col-sm-12">
		       
		        <p>
		        <p>
		       A large young working population  with an age of 35 years , nuclear families , increasing  working women population &  dawning opportunities  in the sector of service  is going to be the prominent factors  in the  growth of organizes Retail sector in India.<br /><br />
	CPIT Is conducting Employment linked skilled Programmes keeping in mind the shortage  of skilled manpower in Retail Sector. CPIT conducts customized corporate trainings to skill students in Different aspects of Retail:<br />
-	Soft  Skills<br />
-	Knowledge regarding Product<br />
-	Customer Service Skills<br /><br />

The Retail sector has played a remarkable role throughout the world in  increasing productivity  of Consumers' goods & services. The Indian Retail Industry is the largest industry among all Industries. The Retail Industry in India has come forth as one of the most effectual Industry with several players coming in the market, but all of them  haven't tasted success yet  as heavy investments  are required  to compete with various companies.<br /><br />

CPIT assures to provide training  in various courses aligned to  NCVT & SSC :<br />
			</p></p>
		        </div>
		
        </div>
        </div>
        <!-- ============== Add ============== -->
        
        <!-- /.container -->
        <!-- ============== Our team ============== -->
        
            <!-- /.container -->
        </div>
<br>

<br>
        

<?php $this->load->view('footer.php')?>