<!DOCTYPE html>
<html>
  <head>
    <title>Accounting</title>
  </head>
  <body>
  <div class="row">
  <div class="col-md-12">
  <div class="dropdown" style="margin:100px;">
  <button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown">Search Option
  <span class="caret"></span></button>
  <ul class="dropdown-menu">
    <li><a href="#">Batch Wise</a></li>
    <li><a href="#">Course Wise</a></li>
    <li><a href="#">student Wise</a></li>
  </ul>
</div>
      </div>
      </div>
  </body>
</html>