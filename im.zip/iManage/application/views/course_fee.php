<!DOCTYPE html>
<html>
  <head>
    <title></title>
  </head>
  <body>
  <div class="row">
    <div class="col-md-3">
        <div class="dropdown" style="margin:100px;">
            <button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown">Select Course
            <span class="caret"></span></button>
            <ul class="dropdown-menu">
                <?php $dt=$this->db->get('courses')->result(); 
                foreach ($dt as $courses)
                {?> 
                <li value="<?php echo $courses->id;?>"><a href="<?php echo base_url();?>index.php/apanel/Coursefee2/<?php echo $courses->id;?>">
                <?php echo $courses->course_name; ?>
                </a></li>
                <?php }
                ?>
            </ul>
        </div>
    </div>
  </div>
  <div class="col-md-3">
    <?php ?>
  </div>
  </body>
</html>