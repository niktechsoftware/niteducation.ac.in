  
        <script src="<?php echo base_url();?>assets/plugins/jquery-ui/jquery-ui.min.js"></script>
        <script src="<?php echo base_url();?>assets/plugins/pace-master/pace.min.js"></script>
        <script src="<?php echo base_url();?>assets/plugins/jquery-blockui/jquery.blockui.js"></script>
        <script src="<?php echo base_url();?>assets/plugins/bootstrap/js/bootstrap.min.js"></script>
        <script src="<?php echo base_url();?>assets/plugins/jquery-slimscroll/jquery.slimscroll.min.js"></script>
        <script src="<?php echo base_url();?>assets/plugins/switchery/switchery.min.js"></script>
        <script src="<?php echo base_url();?>assets/plugins/uniform/jquery.uniform.min.js"></script>
        <script src="<?php echo base_url();?>assets/plugins/classie/classie.js"></script>
        <script src="<?php echo base_url();?>assets/plugins/waves/waves.min.js"></script>
        <script src="<?php echo base_url();?>assets/plugins/3d-bold-navigation/js/main.js"></script>
        <script src="<?php echo base_url();?>assets/plugins/waypoints/jquery.waypoints.min.js"></script>
        <script src="<?php echo base_url();?>assets/plugins/jquery-counterup/jquery.counterup.min.js"></script>
        <script src="<?php echo base_url();?>assets/plugins/toastr/toastr.min.js"></script>
        <script src="<?php echo base_url();?>assets/plugins/flot/jquery.flot.min.js"></script>
        <script src="<?php echo base_url();?>assets/plugins/flot/jquery.flot.time.min.js"></script>
        <script src="<?php echo base_url();?>assets/plugins/flot/jquery.flot.symbol.min.js"></script>
        <script src="<?php echo base_url();?>assets/plugins/flot/jquery.flot.resize.min.js"></script>
        <script src="<?php echo base_url();?>assets/plugins/flot/jquery.flot.tooltip.min.js"></script>
        <script src="<?php echo base_url();?>assets/plugins/curvedlines/curvedLines.js"></script>
        <script src="<?php echo base_url();?>assets/plugins/metrojs/MetroJs.min.js"></script>
        <script src="<?php echo base_url();?>assets/js/modern.min.js"></script>
        <script src="<?php echo base_url();?>assets/js/pages/dashboard.js"></script>
        
         <script>
	        jQuery(document).ready(function() {
				
				alert("o");
	        });
	    </script>