<?php
 class courses extends CI_Model{
 	
 }