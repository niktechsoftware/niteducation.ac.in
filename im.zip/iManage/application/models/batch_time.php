<?php
	class batch_time extends CI_Model{
		
	}
