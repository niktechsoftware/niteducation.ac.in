<?php
	class batch_new extends CI_Model{
		
	}
